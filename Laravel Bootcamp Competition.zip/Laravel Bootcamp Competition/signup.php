<?php
session_start();
include_once "db_library/accounts.class.php";
include_once "db_library/home_class.php";
$min_objs = new home_page();
$min_obj = new accounts();
?>

<!DOCTYPE html>

<html>
<head>
    <meta charset="UTF-8">
    <!-- Mobile viewport optimized -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <!-- Website Title & Description for Search Engine purposes -->
    <title></title>
    <meta name="description"
          content="Learn how to code your first responsive website with the new Twitter Bootstrap 3.">
    <!-- Bootstrap core CSS -->
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="dist/css/bootstrap-rtl.min.css" rel="stylesheet">
    <link href="dist/css/font-awesome.min.css" rel="stylesheet">
    <link href="dist/css/sweetalert.css" rel="stylesheet">
    <!-- Custom CSS -->

    <link rel="stylesheet" href="includes/css/styles.css">
    <style>.alert {
            display: none;
        }</style>

</head>
<body>

<div class="container-fluid move-menu sta" style="background-color: #FFFFFF;top: 0; left: 0;width: 100%;z-index: 10023;">

    <!--Start header -->
    <div class="row">

        <div class="col-sm-2 logo">موقع متجر أون لاين</div>
        <div class="col-sm-3">
            <div class="search">
                <form>
                    <span class="glyphicon glyphicon-search"></span>
                    <input type="text" name="" id="" placeholder="ابحث داخل متجر أون لاين"/>
                </form>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="auth-area">
                <?php
                if (isset($_SESSION['id']) == 0) {
                    echo ' <a href="signin.php">تسجيل الدخول</a>
                |
                               <a href="signup.php">مستخدم جديد</a>';
                } else {
                    echo $_SESSION['name'];
                    echo ' <a href="index.php" class="out">تسجيل الخروج</a>';
                }
                ?>
            </div>
        </div>
        <div class="col-sm-3 call">
            <div>
                <span class="glyphicon glyphicon-bell"></span>
                لاتتردد في الاتصال بنا على +972597063252
            </div>
        </div>
    </div>
    <!--End header -->

    <!--Start menu -->
    <div class="row menu">
        <div class="col-sm-8">
            <div class="main-menu">
                <a href="index.php" style="margin-left: 20px;">الرئيسية</a>
                <?php
                $cat_data = $min_objs->get_main_category();
                foreach ($cat_data as $ycat_data) { ?>
                    <a href="category.php?category_id=<?=$ycat_data['cat_id']?>" style="margin-left: 20px;"><?= $ycat_data["cat_name"] ?></a>
                <?php } ?>
            </div>
        </div>
        <div class="col-sm-2">
            <a href="#">SALES</a>
            <span class="glyphicon glyphicon-fire"></span>
        </div>
        <div class="col-sm-2">
            <span class="glyphicon glyphicon-shopping-cart"></span>
            <a href="#" class="white-link">
                سلة المشتريات
                (
                <span class="total"><?php if (isset($_SESSION['cart']) == null) {
                        echo "0";
                    } else {
                        echo count($_SESSION['cart']);
                    }

                    ?></span>
                )
            </a>
        </div>
    </div>
    <!--End menu -->
</div>
<div class="container-fluid">
    <!--Start contents -->
    <div class="row">

        <div class="col-sm-9">
            <div class="white-box"
                 style="margin-top: 10px; visibility: visible; animation-name: fadeInDown;">

                <div class="row" style="padding-top:10px; padding-right:10px;">
                    <div class="col-sm-12" style="color:#F3C634; font-size:13px;">
                        <i class="fa fa-cart-plus"></i>
                        مستخدم جديد
                    </div>
                </div>


                <div class="row" style="padding-top:10px; padding-right:10px; padding-left:10px;">
                    <div class="col-sm-12" style="font-size:13px;">

                        <div class="row">

                            <div class="col-sm-2">
                            </div>

                            <div class="col-sm-8">
                                <form class="sign-up form-group">
                                    <div style="padding:5px;">
                                        <input type="text" name="username" id="username" class="form-control"
                                               required="required" placeholder="اسم المستخدم"/>
                                    </div>
                                    <div style="padding:5px;">
                                        <input type="text" class="form-control" id="mobile"
                                               name="mobile"
                                               placeholder="رقم الموبايل ليتم التواصل في حالة الشراء"
                                               style="font-size:12px;" autocomplete="off"></div>
                                    <div style="padding:5px;">
                                        <input type="email" name="email" id="email" class="form-control"
                                               required="required"
                                               placeholder="البريد الالكتروني"/>
                                    </div>
                                    <div style="padding:5px;">
                                        <input type="password" name="password" id="password" class="form-control"
                                               required="required" placeholder="كلمة المرور"/>
                                    </div>
                                    <div style="padding:5px;">
                                        <input type="password" name="rePassword" id="rePassword" class="form-control"
                                               required="required" placeholder="اعد كلمة المرور"/>
                                    </div>
                                    <div style="padding:5px;">
                                        <input type="button" class="form-control btn btn-success sign-up-btn"
                                               value="سجل الان"/>
                                    </div>
                                    <div style="padding:5px;">
                                        <a href="#" id="reg" name="reg" style="font-size:12px;">
                                            <span class="glyphicon glyphicon-alert"></span>
                                            لايمكن الدخول الي حسابي , استرجاع كلمة المرور
                                        </a></div>
                                </form>
                            </div>

                            <div class="col-sm-2">
                            </div>

                        </div>


                    </div>
                </div>

            </div>
        </div>

        <div class="col-sm-3">

            <div class="white-box">
                <div class="row" style="padding-top:10px; padding-right:10px;">
                    <div class="col-sm-6" style="color:#F3C634; font-size:13px;">
                        <span class="glyphicon glyphicon-align-justify"></span>
                        الأكثر طلبا
                    </div>
                    <div class="col-sm-6" style="color:#F3C634; font-size:13px; text-align:left; ">
                        <div style="padding-left:10px;">
                            <span class="glyphicon glyphicon-eye-open" style="font-size:14px; "></span> (300)
                            <span class="glyphicon glyphicon-thumbs-up" style="font-size:14px;"></span> (200)
                        </div>

                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box" style="border:none;">
                            <?php
                            $cat_data = $min_objs->get_main_cart();
                            foreach ($cat_data as $ycat_data) { ?>

                                <?php
                                $products_data = $min_objs->get_cart_products($ycat_data['products_id']);
                                foreach ($products_data as $s) {
                                    ?>
                                    <div class="products_box">
                                        <div><img src="products_img/<?= $s['p_img'] ?>" class="img-thumbnail"></div>
                                        <div><?= $s['p_title'] ?></div>
                                        <div><?= $s['p_price'] ?></div>
                                        <div>
                                            <input type="hidden" name="" id="" value="<?= $s['p_id'] ?>"
                                                   class="current-id"/>
                                            <input type="button" name="" id="" value="اطلب الان"
                                                   class="btn btn-danger add-cart"/>
                                        <span class="current_loader" style="display:none;">
                                        <img src="images/ajax-loader.gif" width="20" height="20"/>
                                        </span>
                                        </div>
                                        <div><i class="fa fa-eye"></i>300 <i class="fa fa-thumbs-up"></i>200</div>
                                    </div>
                                    <?php
                                }
                                ?>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>

            <div
                style="border-color:#B7B1B1; border-style:dashed; border-width:1px;margin-top:10px; text-align:center; padding:20px; font-size:20px;"
                class="rounded-corner">
                <div>
                    مساحة اعلانية .... اتصل الان واحجز اعلانك
                </div>
                <div style=" padding-left:10px;" align="left">
                    <a href="" class="btn btn-info">احجزه الان</a>
                </div>
            </div>

            <div class="white-box">
                <div class="row" style="padding-top:10px; padding-right:10px;">
                    <div class="col-sm-6" style="color:#F3C634; font-size:13px;">
                        <span class="glyphicon glyphicon-align-justify"></span>
                        الأكثر مشاهدة
                    </div>
                    <div class="col-sm-6" style="color:#F3C634; font-size:13px; text-align:left; ">
                        <div style="padding-left:10px;">
                            <span class="glyphicon glyphicon-eye-open" style="font-size:14px; "></span> (300)
                            <span class="glyphicon glyphicon-thumbs-up" style="font-size:14px;"></span> (200)
                        </div>

                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box" style="border:none;">
                            <?php
                            $cat_data = $min_objs->get_main_cart();

                            foreach ($cat_data as $ycat_data) { ?>

                                <?php
                                $products_data = $min_objs->get_cart_products($ycat_data['products_id']);
                                foreach ($products_data as $s) {
                                    ?>
                                    <div class="products_box">
                                        <div><img src="products_img/<?= $s['p_img'] ?>" class="img-thumbnail"></div>
                                        <div><?= $s['p_title'] ?></div>
                                        <div><?= $s['p_price'] ?></div>
                                        <div>
                                            <input type="hidden" name="" id="" value="<?= $s['p_id'] ?>"
                                                   class="current-id"/>
                                            <input type="button" name="" id="" value="اطلب الان"
                                                   class="btn btn-danger add-cart"/>
                                        <span class="current_loader" style="display:none;">
                                        <img src="images/ajax-loader.gif" width="20" height="20"/>
                                        </span>
                                        </div>
                                        <div><i class="fa fa-eye"></i>300 <i class="fa fa-thumbs-up"></i>200</div>
                                    </div>
                                    <?php
                                }
                                ?>
                            <?php } ?>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-12">
                        <div style="padding-left:10px; padding-bottom:20px; padding-top:10px;" align="left">

                            <a href="">
                                <span class="glyphicon glyphicon-th"></span>
                                أرشيف الاكثر مشاهدة
                            </a>
                        </div>
                    </div>
                </div>

            </div>


        </div>

    </div>
    <!--End contents -->

    <!--Start about -->
    <div class="row about">
        <div class="col-sm-8">
            <p class="title">موضة أون لاين</p>
            <p class="details">موقع فلسطيني يقدم خدماته لأهالينا في قطاع غزة , الموقع مخصص لبيع الادوات الالكترونية مع العلم أن خدمة
                التوصيل مجانية . كل ما عليك هو الشراء والدفع عند معاينة واستلام بضاعتك موقع فلسطيني يقدم خدماته لأهالينا
                في قطاع غزة , الموقع مخصص لبيع الادوات الالكترونية مع العلم أن خدمة التوصيل مجانية . كل ما عليك هو الشراء والدفع عند
                معاينة واستلام بضاعتك</p>
        </div>
        <div class="col-sm-4">
            <p class="title1">عن الشركة</p>
            <ul>
                <li><a href="#">من نحن</a></li>
                <li><a href="#">اتصل بنا</a></li>
                <li><a href="#">الموزعون</a></li>
                <li><a href="#">سياسة العمل</a></li>
            </ul>
        </div>
    </div>
    <!--End about -->

    <!--Start footer -->
    <div class="row footer">
        <div class="col-sm-8"> جميع الحقوق محفوظة لمتجر أون لاين 2016</div>
        <div class="col-sm-4">
            <div class="footer-icon">
                <a href="#"><i class="fa fa-facebook-square fa-2x"></i></a>
                <a href="#"><i class="fa fa-twitter-square fa-2x"></i></a>
                <a href="#"> <i class="fa fa-pinterest-square fa-2x"></i></a>
            </div>
        </div>
    </div>
    <!--End footer -->

</div>


<!-- All Javascript at the bottom of the page for faster page loading -->

<script src="js/jquery-1.11.3.js"></script>

<script src="dist/js/bootstrap.min.js"></script>
<script src="dist/js/sweetalert.min.js"></script>
<script src="dist/js/sweetalert-dev.js"></script>

<script type="text/javascript">



    $(document).ready(function () {

        $(window).scroll(function() {
            if($(window).scrollTop() > 10) {
                $('.move-menu').removeClass("sta");
                $('.move-menu').addClass("move");
                $('.move-menu').addClass("alpha60");
            } else {
                $('.move-menu').addClass("sta");
                $('.move-menu').removeClass("move");
                $('.move-menu').removeClass("alpha60");
            }
        });

        $('.out').on("click", function () {
            $.ajax({
                type: "POST",
                url: "services/signout.php",
                data: {},
                cache: "false",
                success: function (data) {
                    alert(data);
                }
            });
        })

        $('.sign-up-btn').on("click", function () {
            $.ajax({
                type: "POST",
                url: "services/signup.php",
                data: $(".sign-up").serialize(),
                dataType: "json",
                cache: "false",
            }).done(function () {
                swal({
                    title: "نجح عملية الاشتراك",
                    text: "نتمنى لك قضاء وقت ممتع",
                    type: "success",
                    showCancelButton: false,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "تابع التسوق .. شكرا لك",
                    cancelButtonText: "No, cancel plx!",
                    closeOnConfirm: false,
                    closeOnCancel: false
                }, function (isConfirm) {
                    if (isConfirm) {
                        window.location = "signin.php";
                    }
                });
            }).fail(function () {
                swal("مشكلة في تسجيل الاشتراك", "الرجاء ادخال جميع البيانات", "error");
            });
        })
    });
</script>
</body>
</html>

