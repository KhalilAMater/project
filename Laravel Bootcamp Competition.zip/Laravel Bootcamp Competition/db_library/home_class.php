<?php

class home_page
{
    private $link;
    private $host = "localhost";
    private $user = "root";
    private $pass = "root";
    private $name_db = "shop1";


    public function __construct()
    {
        $this->link = mysqli_connect($this->host, $this->user, $this->pass, $this->name_db);
        mysqli_query($this->link, "set names 'utf8'");
    }
    // public function add_record($studant_Name, $studant_img)
    // {
    //     //global $link;
    //     //$link = new connect();
    //     //$link->dbConnect();
    //     $sql = "insert into Student(std_name,std_img) VALUE ('$studant_Name','$studant_img')";
    //     mysqli_query($this->link, $sql);
    //     header("Location:select.php");
    // }
    // public function delete_record($get_id_student)
    // {
//
    //     $sql = "delete from Student where std_id='$get_id_student'";
    //     mysqli_query($this->link, $sql);
    // }

    public function get_main_category()
    {
        //limit لجلب عدد معين من المنتجات
        $sql = "SELECT * from cat ORDER by cat_id DESC limit 5 ";
        $query2 = mysqli_query($this->link, $sql);
        $data = array();
        while ($row = mysqli_fetch_array($query2)) {
            $data[] = $row;
        }
        return $data;
    }

    public function get_all_category($cat_id)
    {
        //limit لجلب عدد معين من المنتجات
        $sql = "SELECT * from cat WHERE cat_id='$cat_id'";
        $query2 = mysqli_query($this->link, $sql);
        $data = array();
        while ($row = mysqli_fetch_array($query2)) {
            $data[] = $row;
        }
        return $data;
    }

     public function get_cat_products($cat_id)
     {
         $sql = "SELECT * from products WHERE cat_id='$cat_id' limit 4 ";
         $query_products = mysqli_query($this->link, $sql);
         $data_products = array();
         while ($row_products = mysqli_fetch_array($query_products)) {
             $data_products[] = $row_products;
         }
         return $data_products;
     }

    public function get_cat_all_products($cat_id)
    {
        $sql = "SELECT * from products WHERE cat_id='$cat_id'";
        $query_products = mysqli_query($this->link, $sql);
        $data_products = array();
        while ($row_products = mysqli_fetch_array($query_products)) {
            $data_products[] = $row_products;
        }
        return $data_products;
    }

    public function get_specific_products($id)
    {
        $sql = "SELECT * from products WHERE p_id='$id'";
        $query_products = mysqli_query($this->link, $sql);
        $row_products = mysqli_fetch_array($query_products);
        return $row_products;
    }

    public function get_main_cart()
    {
        $sql = "SELECT products_id,SUM(quantity) AS sum FROM cart GROUP BY products_id ORDER BY sum DESC LIMIT 3";
        $query2 = mysqli_query($this->link, $sql);
        $data = array();
        while ($row = mysqli_fetch_array($query2)) {
            $data[] = $row;
        }
        return $data;
    }

    public function get_cart_products($cart_id)
    {
        $sql = "SELECT * from products WHERE p_id='$cart_id'";
        $query_products = mysqli_query($this->link, $sql);
        $data_products = array();
        while ($row_products = mysqli_fetch_array($query_products)) {
            $data_products[] = $row_products;
        }
        return $data_products;
    }

    public function add_products($views)
    {
        $sql = "INSERT INTO products(views) VALUES ('$views')";
        mysqli_query($this->Link, $sql);
    }

    public function get_all_products($p_id)
    {
        $sql = "SELECT * from products WHERE p_id='$p_id'";
        $query_products = mysqli_query($this->link, $sql);
        $data_products = array();
        while ($row_products = mysqli_fetch_array($query_products)) {
            $data_products[] = $row_products;
        }
        return $data_products;
    }
}

