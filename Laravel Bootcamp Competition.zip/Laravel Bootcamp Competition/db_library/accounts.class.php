<?php

class accounts
{
    private $Link;
    private $host = "localhost";
    private $db_user = "root";
    private $db_password = "root";
    private $db_name = "shop1";

    public function __construct()
    {
        $this->Link = mysqli_connect($this->host, $this->db_user, $this->db_password, $this->db_name);
        mysqli_query($this->Link, "set names 'utf8'");
    }

    //public function login($username,$password)
    //{
    //    $sql="select * from accounts WHERE username='$username' AND password='$password'";
    //    $query=mysqli_query($this->Link,$sql);
    //    if(mysqli_num_rows($query)==0)
    //    {
    //        return null;
    //    }
    //    else
    //    {
    //        $row=mysqli_fetch_array($query);
    //        return $row;
    //    }
    //}

    public function check_login($a, $b)
    {
        $result = mysqli_prepare($this->Link, "select email,salt,username,password,account_id from accounts WHERE email=?");
        $result->bind_param("s", $a);
        $result->execute();
        if (!$result) {
          $data = array("name" => "", "email" => "", "id" => "", "result" => "fail");
            return $data;
        } else {
            mysqli_stmt_bind_result($result, $email, $salt, $username, $password, $account_id);
            mysqli_stmt_fetch($result);
            $hash = hash('sha256', $salt . hash('sha256', $b));
            if ($password == $hash) {
               $data = array("name" => $username, "email" => $email, "id" => $account_id, "result" => "success");
                return $data;
            } else {
               $data = array("name" => "", "email" => "", "id" => "", "result" => "fail");
                return $data;
            }
        }
    }

    public function sign_up($username,$email,$password,$mobile)
    {
        $hash=hash('sha256',$password);
        $string=md5(uniqid(rand(),true));
        $salt=substr($string,0,3);
        $hash=hash('sha256',$salt.$hash);
        $sql="insert into accounts(username,password,email,mobile,salt)VALUE (?,?,?,?,?)";
        $result= mysqli_prepare($this->Link,$sql);
        $result->bind_param("sssss",$username,$hash,$email,$mobile,$salt);
        $result->execute();
    }
}