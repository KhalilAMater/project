<?php

class cart
{

    private $Link;
    private $host = "localhost";
    private $db_user = "root";
    private $db_password = "root";
    private $db_name = "shop1";

    public function __construct()
    {
        $this->Link = mysqli_connect($this->host, $this->db_user, $this->db_password, $this->db_name);
        mysqli_query($this->Link, "set names 'utf8'");
    }

    public function add_cart($products_id, $quantity, $accounts_id,$time_data_stamp,$is_active)
    {
        $result = mysqli_prepare($this->Link, "INSERT INTO cart(products_id,quantity,accounts_id,time_data_stamp,is_active) VALUES (?,?,?,?,?)");
        $result->bind_param("sssss", $products_id, $quantity, $accounts_id, $time_data_stamp,$is_active);
        $result->execute();
    }

}