-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2016 at 02:26 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `shop1`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE IF NOT EXISTS `accounts` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `mobile` int(11) NOT NULL,
  `salt` varchar(300) NOT NULL,
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`account_id`, `username`, `password`, `email`, `mobile`, `salt`) VALUES
(1, 'admin', 'admin', '', 0, ''),
(7, 'km', 'dd98e740d561a4824d0cf7f49a7d72aef68a8e7f3f0e3f193013861215b20847', 'dev@atyaf.co', 0, '701'),
(8, 'khalil123', 'bfcfb6457c75a9149e93dd55cf6a5f3976bcbd7c3b2d4c5ab4bd915a465ee7a1', 'khalil.mater@h.com', 0, '001'),
(16, 'khalilmater1995', '9a04de32882004e68757edb59be6184120e85c6fbd730a4bd7adb4b5e37c0490', 'khalil@hotmail.com', 0, '775'),
(29, 'خليل مطر', '2a59bffbd1b6c1a838fdefe28c4d006c72e3d65348e67b90c7aaabfe2ad25044', 'khalil1995@hotmail.com', 597063252, 'ba3');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `cart_id` int(11) NOT NULL AUTO_INCREMENT,
  `accounts_id` int(11) NOT NULL,
  `products_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `time_data_stamp` datetime NOT NULL,
  `is_active` int(11) NOT NULL,
  PRIMARY KEY (`cart_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=111 ;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `accounts_id`, `products_id`, `quantity`, `time_data_stamp`, `is_active`) VALUES
(1, 8, 19, 2, '2016-03-19 03:03:49', 0),
(2, 8, 18, 1, '2016-03-19 03:03:49', 0),
(3, 8, 17, 5, '2016-03-19 03:03:49', 0),
(4, 8, 19, 3, '2016-03-20 09:03:46', 0),
(5, 8, 18, 3, '2016-03-20 09:03:46', 0),
(6, 8, 17, 3, '2016-03-20 09:03:46', 0),
(8, 8, 14, 1, '2016-03-20 09:03:46', 0),
(9, 8, 15, 1, '2016-03-20 09:03:46', 0),
(10, 8, 16, 1, '2016-03-20 09:03:46', 0),
(11, 16, 19, 1, '2016-03-20 10:03:43', 0),
(12, 16, 18, 1, '2016-03-20 10:03:43', 0),
(13, 16, 17, 1, '2016-03-20 10:03:43', 0),
(14, 16, 14, 1, '2016-03-20 10:03:43', 0),
(15, 16, 15, 1, '2016-03-20 10:03:43', 0),
(16, 16, 16, 1, '2016-03-20 10:03:43', 0),
(18, 16, 19, 1, '2016-03-20 10:03:20', 0),
(19, 16, 19, 1, '2016-03-20 10:03:37', 0),
(20, 16, 18, 1, '2016-03-20 10:03:37', 0),
(21, 16, 17, 1, '2016-03-20 10:03:37', 0),
(22, 16, 16, 1, '2016-03-20 10:03:37', 0),
(23, 16, 15, 1, '2016-03-20 10:03:37', 0),
(24, 16, 19, 1, '2016-03-20 10:03:11', 0),
(25, 16, 18, 1, '2016-03-20 10:03:11', 0),
(26, 16, 17, 1, '2016-03-20 10:03:11', 0),
(27, 16, 19, 3, '2016-03-20 10:03:23', 0),
(28, 16, 18, 3, '2016-03-20 10:03:23', 0),
(29, 16, 17, 3, '2016-03-20 10:03:23', 0),
(30, 16, 18, 1, '2016-03-20 10:03:55', 0),
(31, 16, 17, 1, '2016-03-20 10:03:55', 0),
(32, 16, 19, 1, '2016-03-20 10:03:55', 0),
(33, 16, 19, 1, '2016-03-20 10:03:20', 0),
(34, 16, 18, 1, '2016-03-20 10:03:20', 0),
(35, 16, 18, 1, '2016-03-20 11:03:18', 0),
(36, 16, 17, 1, '2016-03-20 11:03:18', 0),
(37, 16, 19, 1, '2016-03-20 11:03:18', 0),
(38, 16, 19, 1, '2016-03-20 11:03:33', 0),
(39, 16, 18, 1, '2016-03-20 11:03:33', 0),
(40, 16, 17, 1, '2016-03-20 11:03:33', 0),
(41, 16, 19, 1, '2016-03-20 11:03:40', 0),
(42, 16, 18, 1, '2016-03-20 11:03:40', 0),
(43, 16, 19, 1, '2016-03-20 11:03:47', 0),
(44, 16, 18, 1, '2016-03-20 11:03:47', 0),
(45, 16, 17, 1, '2016-03-20 11:03:47', 0),
(46, 16, 17, 1, '2016-03-20 11:03:30', 0),
(47, 16, 18, 1, '2016-03-20 11:03:30', 0),
(48, 16, 19, 1, '2016-03-20 11:03:30', 0),
(49, 16, 19, 1, '2016-03-20 11:03:05', 0),
(50, 16, 19, 1, '2016-03-20 11:03:29', 0),
(51, 16, 19, 1, '2016-03-20 11:03:00', 0),
(52, 16, 19, 1, '2016-03-20 11:03:07', 0),
(53, 16, 19, 1, '2016-03-20 11:03:24', 0),
(54, 16, 19, 1, '2016-03-20 11:03:56', 0),
(55, 16, 18, 1, '2016-03-20 11:03:56', 0),
(56, 16, 17, 1, '2016-03-20 11:03:56', 0),
(57, 16, 19, 1, '2016-03-20 11:03:45', 0),
(58, 16, 18, 1, '2016-03-20 11:03:45', 0),
(59, 16, 19, 1, '2016-03-20 11:03:18', 0),
(60, 16, 19, 1, '2016-03-20 11:03:07', 0),
(61, 16, 18, 1, '2016-03-20 11:03:07', 0),
(62, 16, 19, 1, '2016-03-20 02:03:53', 0),
(63, 16, 18, 1, '2016-03-20 02:03:53', 0),
(64, 16, 17, 1, '2016-03-20 02:03:53', 0),
(65, 16, 19, 1, '2016-03-20 03:03:44', 0),
(66, 16, 18, 1, '2016-03-20 03:03:44', 0),
(67, 16, 17, 1, '2016-03-20 03:03:44', 0),
(68, 16, 18, 1, '2016-03-20 03:03:46', 0),
(69, 16, 19, 1, '2016-03-20 03:03:46', 0),
(74, 16, 19, 1, '2016-03-21 11:03:19', 0),
(75, 16, 14, 6, '2016-03-21 12:03:39', 0),
(76, 16, 15, 6, '2016-03-21 12:03:39', 0),
(77, 16, 20, 3, '2016-03-21 12:03:08', 0),
(78, 16, 18, 1, '2016-03-21 12:03:22', 0),
(79, 16, 19, 1, '2016-03-21 12:03:22', 0),
(80, 16, 20, 1, '2016-03-21 01:03:31', 0),
(81, 16, 19, 1, '2016-03-21 01:03:31', 0),
(82, 16, 18, 1, '2016-03-21 01:03:31', 0),
(83, 16, 19, 1, '2016-03-21 02:03:19', 0),
(84, 16, 20, 1, '2016-03-21 02:03:33', 0),
(85, 16, 20, 1, '2016-03-21 10:03:11', 0),
(86, 16, 19, 1, '2016-03-21 10:03:11', 0),
(87, 16, 20, 1, '2016-03-22 09:03:11', 0),
(88, 16, 30, 1, '2016-03-22 03:03:49', 0),
(90, 16, 19, 1, '2016-03-22 03:03:49', 0),
(91, 16, 24, 2, '2016-03-22 03:03:49', 0),
(92, 16, 30, 1, '2016-03-22 03:03:55', 0),
(93, 16, 15, 1, '2016-03-24 02:03:33', 0),
(94, 16, 20, 3, '2016-03-24 02:03:33', 0),
(95, 29, 20, 1, '2016-03-24 03:03:47', 0),
(96, 16, 20, 1, '2016-03-26 09:03:18', 0),
(97, 16, 19, 1, '2016-03-26 09:03:18', 0),
(98, 16, 18, 1, '2016-03-26 09:03:18', 0),
(99, 16, 14, 1, '2016-03-28 11:03:55', 0),
(100, 16, 30, 1, '2016-03-30 08:03:15', 0),
(101, 16, 29, 1, '2016-03-30 08:03:49', 0),
(102, 16, 19, 1, '2016-03-31 06:03:53', 0),
(103, 16, 30, 1, '2016-03-31 01:03:05', 0),
(104, 29, 30, 1, '2016-04-04 10:04:12', 1),
(105, 29, 29, 1, '2016-04-04 10:04:12', 1),
(106, 16, 21, 6, '2016-04-05 09:04:13', 1),
(107, 16, 20, 3, '2016-04-05 09:04:13', 1),
(108, 16, 19, 2, '2016-04-05 09:04:13', 1),
(109, 16, 18, 2, '2016-04-05 09:04:13', 1),
(110, 16, 30, 1, '2016-04-07 10:04:23', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cat`
--

CREATE TABLE IF NOT EXISTS `cat` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(500) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `cat`
--

INSERT INTO `cat` (`cat_id`, `cat_name`) VALUES
(4, 'كاميرات'),
(5, 'شاشات\n'),
(6, 'لابتوبات '),
(7, 'جوالات'),
(8, 'اكسسوارات');

-- --------------------------------------------------------

--
-- Table structure for table `online`
--

CREATE TABLE IF NOT EXISTS `online` (
  `id_online` int(11) NOT NULL AUTO_INCREMENT,
  `ip_online` varchar(200) NOT NULL,
  `time_online` varchar(300) NOT NULL,
  `browser` varchar(200) NOT NULL,
  `Country` varchar(300) NOT NULL,
  PRIMARY KEY (`id_online`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `online`
--

INSERT INTO `online` (`id_online`, `ip_online`, `time_online`, `browser`, `Country`) VALUES
(13, '::1', '1460290450', 'Google Chrome', '');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT,
  `p_title` varchar(300) DEFAULT NULL,
  `p_price` double DEFAULT NULL,
  `p_desc` text,
  `p_img` varchar(100) DEFAULT NULL,
  `views` int(11) NOT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`p_id`, `p_title`, `p_price`, `p_desc`, `p_img`, `views`, `cat_id`) VALUES
(14, 'samsung-galaxy-s6-edge-gold', 500, 'samsung-galaxy-s6-edge-gold', '56f67f664fce5160326240106.jpg', 0, 7),
(15, 'samsung note4 edge lte whitesd', 250.99, 'samsung note4 edge lte white', '56f67feec875b160326260122.jpg', 0, 7),
(16, 'iphone-6-plus-gold', 800, 'iphone-6-plus-gold', '56f68029b62c4160326270121.png', 0, 7),
(17, 'i-phone-6s-silver', 900, 'i-phone-6s-silver', '56f68042db93c160326270146.gif', 0, 7),
(18, 'MSI used CES 2015', 250.99, 'MSI used CES 2015', '56f78c80dc5fd160327320916.jpg', 0, 6),
(19, 'macbook pro', 900, 'macbook pro', '56f78cb790817160327330911.png', 0, 6),
(20, 'laptop hp', 250.99, 'laptop hp', '56f78ce348b75160327330955.jpg', 0, 6),
(21, 'laptop samsung', 250.99, 'laptop samsung', '56f78d127461d160327340942.jpg', 0, 6),
(22, 'LCD LG', 250.99, 'LCD LG', '56f78d730c8f9160327360919.jpg', 0, 5),
(23, 'lcd samsung', 300, 'lcd samsung', '56f78daba0b1e160327370915.jpg', 0, 5),
(24, 'lcd toshiba', 250.99, 'lcd toshiba', '56f78dc96deb7160327370945.jpg', 0, 5),
(25, 'camera sony', 450, 'camera sony', '56f78e09b0782160327380949.png', 0, 4),
(26, 'camera canon', 860, 'camera canon', '56f78e3287ca8160327390930.jpg', 0, 4),
(27, 'Etrain laptop bag Model BG022', 250.99, 'Etrain laptop bag Model BG022', '56f78eedb88ae160327420937.jpg', 0, 8),
(28, '2B Earphone for Smart phones Model NO. HP054dasdasd', 250.99, '2B Earphone for Smart phones Model NO. HP054\r\n', '56f78f39a5a0d160327430953.jpg', 0, 8),
(29, 'Wireless Bluetooth Mouse model no MO864', 250.99, 'Wireless Bluetooth Mouse model no MO864\r\n', '56f78f82c277c160327450906.jpg', 0, 8),
(30, 'Subwoofer 2B 2.1 Speaker', 250.99, 'Subwoofer 2B 2.1 Speaker', '56f78fe23aa18160327460942.jpg', 0, 8);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
