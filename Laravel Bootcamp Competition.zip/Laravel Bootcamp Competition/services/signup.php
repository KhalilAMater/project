<?php
include_once ("../db_library/accounts.class.php");
$account=new accounts();
$username=filter_input(INPUT_POST,'username');
$email=filter_input(INPUT_POST,'email');
$mobile=filter_input(INPUT_POST,'mobile');
$password=filter_input(INPUT_POST,'password');
$rePassword=filter_input(INPUT_POST,'rePassword');
if($username=="" || $email=="" || $mobile=="" || $password=="" || $rePassword=="")
{
    echo "يرجا ادخال جميع البيانات";
}
elseif($password!=$rePassword)
{
    echo "الباسورد غير متتطابق";
}
else
{
    $account->sign_up($username,$email,$password,$mobile);
}
echo json_encode($account);