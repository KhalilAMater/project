<?php
session_start();
$p_id=$_POST['p_id'];
if(isset($_SESSION['cart'][$p_id]))
{
    $_SESSION['cart'][$p_id]++;
}else
{
    $_SESSION['cart'][$p_id]=1;
}
$count=0;
foreach($_SESSION['cart']as $id=>$x)
{
    $count++;
}
echo json_encode($count);

