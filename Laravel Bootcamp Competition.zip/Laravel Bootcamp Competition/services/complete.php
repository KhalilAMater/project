<?php session_start();
include_once("../db_library/cart.class.php");

$a = new cart();

if (isset($_SESSION['id']) == 0) {

} else {
    foreach ($_SESSION['cart'] as $id => $x) {
        $x = $a->add_cart($id, $x, $_SESSION['id'], date('y-m-d h:m:s'),'1');
    }
    unset($_SESSION['cart']);
}

echo json_encode(isset($_SESSION['id'])!=0);