<?php
session_start();
$p_id=$_POST['p_id'];
unset($_SESSION['cart'][$p_id]);
$count=0;
foreach($_SESSION['cart']as $id=>$x)
{
    $count++;
}
echo json_encode($count);