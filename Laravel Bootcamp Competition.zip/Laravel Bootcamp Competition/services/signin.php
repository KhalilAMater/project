<?php session_start();
include_once("../db_library/accounts.class.php");
$email = filter_input(INPUT_POST, 'email');
$password = filter_input(INPUT_POST, 'password');
$a = new accounts();
$x = $a->check_login($email, $password);

if ($x['result'] == "success") {
    $_SESSION['name'] = $x['name'];
    $_SESSION['id'] = $x['id'];
}
echo json_encode($x);