$(document).ready(function() {
    
    // Run Nice Scroll Library                  
    $("html").niceScroll({
        scrollspeed: 20,
        cursorcolor:"#2c3e50",
        cursorwidth:6,
        cursorborder:"0",
        zindex: "9999",
        cursorborderradius:"3px"
    });
    
    // Open Sidebar
    
    $('.toggle-btn').click(function(){
        sidebar = $('.sidebar-right').attr('data-bar');
        
        if (sidebar == "none") {
            $(".sidebar-right").css({ 
                'right' : "0", 
                'transition' : "0.5s"
            });
            
            $(".icon-check").css({ 
                'transform':"rotate(180deg)",
                '-webkit-transform':"rotate(180deg)",
                '-moz-transform':"rotate(180deg)", 
                '-o-transform':"rotate(180deg)"
            });
            
            $('.sidebar-right').attr('data-bar', 'blok');
        } else {
            
            $(".sidebar-right").css({ 
                'right' : "-300px", 
                'transition' : "0.5s"
            });
            
            $(".icon-check").css({ 
                'transform':"rotate(360deg)",
                '-webkit-transform':"rotate(360deg)",
                '-moz-transform':"rotate(360deg)", 
                '-o-transform':"rotate(360deg)"
            });
            
            $('.sidebar-right').attr('data-bar', 'none'); 
        }
        //return false;
    });
});