<?php
session_start();
include_once '../db_products/products.class.php';
include_once '../db_user/user.class.php';
include_once '../fun/functions.php';
include_once '../db_Categories/Categories.class.php';
include_once '../db_library/cart.class.php';
include_once '../db_library/admin_page.php';
include_once '../db_user/user.class.php';
if (!isset($_SESSION['form-username']) or empty($_SESSION['form-username'])) {
    header("Location:../index.php");
}
$products_obj = new products_Operations();
$main_cat = new Categories_Operations();
$main_obj = new cart_admin();
$a = new admin_page();
$accounts = new user_Operations();


?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>تحكم - تحكم بعالمك!</title>
    <link rel="stylesheet" href="../dits/css/style.css">
</head>
<body>
<!-- Start sidebar-right -->
<section class="sidebar-right" data-bar="none">

    <label for="toggle" class="toggle-btn">
        <input class="toggle-btn" type="checkbox" id="toggle">
        <span class="icon-check"></span>
    </label>

    <ul class="sidebar">
        <li class="nav-header">
            <a data-toggle="collapse" data-target="#userMenu">
                <i class="fa fa-home"></i>لوحة التحكم
            </a>
            <ul style="list-style: none;" class="collapse in" id="userMenu">
                <li class="active"><a href="../../index.php" target="_blank"><i class="icon-home"></i>عرض الموقع</a>
                </li>
                <li><a href="#"><i class="icon-cogs"></i>إعدادات عامة</a></li>
                <li><a href="#"><i class="icon-off"></i>مساعدة</a></li>
            </ul>
        </li>

        <li class="nav-header">
            <a data-toggle="collapse" data-target="#email">
                <i class="fa fa-envelope"></i>التصنيفات<span class="badge">
                  <?php
                  $main_cat->get_count_category()
                  ?>
                </span>
            </a>
            <ul style="list-style: none;" class="collapse" id="email">
                <li><a href="../Categories/add_Categories.php">اضافة تصنيف</a></li>
                <li><a href="#">عرض التصنيفات</a></li>
            </ul>
        </li>


        <!--  <<li class="nav-header">
             <a data-toggle="collapse" data-target="#email">
               <i class="fa fa-envelope"></i>خدمات البريد<span class="badge">10</span>
             </a>
             <ul style="list-style: none;" class="collapse" id="email">
               <li><a href="#">الواردة</a></li>
               <li><a href="#">المهملة</a></li>
               <li><a href="#">الصادرة</a></li>
             </ul>
           </li>-->

        <li class="nav-header">
            <a data-toggle="collapse" data-target="#cloud">
                <i class="fa fa-cloud"></i>المنتجات<span class="badge">
                    <?php
                    $products_obj->get_count_products()
                    ?>
                </span>
            </a>
            <ul style="list-style: none;" class="collapse" id="cloud">
                <li><a href="add_products.php">اضافة منتج</a></li>
                <li><a href="index.php">عرض المنتجات</a></li>
            </ul>
        </li>

        <li class="nav-header">
            <a data-toggle="collapse" data-target="#chart">
                <i class="fa fa-area-chart"></i>المزيد
            </a>
            <ul style="list-style: none;" class="collapse" id="chart">
                <li>
                    <a href="#">
                        المتواجدون الان
                        <span class="badge" style="float: none">
                            <?php
                            $a->get_ip_online();
                            ?>
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        عدد الزوار
                        <span class="badge" style="float: none">
                            <?php
                            $a->get_all_ip_online();
                            ?>
                        </span>
                    </a>
                </li>

                <li>
                    <a href="index.php">
                        المبيعات
                    </a>
                </li>

                <li>
                    <a href="#">
                        عدد المبيعات
                        <span class="badge" style="float: none"><?php
                            $main_obj->get_count_cart()
                            ?>
                        </span>
                    </a>
                </li>
            </ul>
        </li>
    </ul>
    <div class="clearfix"></div>
</section><!-- End sidebar-right -->
<!-- Start Header -->
<nav class="header navbar navbar-default">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand logo" href="../home.php"><img src="../dits/img/logo%20(1).png"
                                                                 class="img-responsive"></a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="navbar">
            <ul class="nav navbar-nav">
                <li class="active"><a href="#">لوحة التحكم</a></li>
                <li><a href="../cart/cart-un-active.php">الاشعارات
                                    <span class="badge">
                                        <?php
                                        $main_obj->get_count_cart_un_active();
                                        ?>
                                    </span>
                    </a>
                </li>
                <li><a href="../chart.php">الاحصائيات</a></li>
            </ul>

            <div class="user">
                <ul class="nav nav-tabs">
                    <li role="presentation" class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-expanded="false">
                            <img src="../dits/img/user-img.jpg" alt="">
                            <p>المدير</p>
                            <i class="fa fa-caret-down"></i>
                        </a>

                        <ul class="dropdown-menu" role="menu">

                            <li><a href="../cart/cart-un-active.php">الاشعارات
                                    <span class="badge">
                                        <?php
                                        $main_obj->get_count_cart_un_active();
                                        ?>
                                    </span>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div><!-- User -->
        </div><!-- /.navbar-collapse -->

    </div><!-- /.container -->
</nav>


<section class="charts no-margin">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 margin">
                <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>IP</th>
                        <th>المتصفح</th>
                        <th>الوقت</th>
                        <th>حذف</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $result = $a->get_online();
                    foreach ($result as $r) {
                        ?>
                        <tr>
                            <td><?= $r['id_online'] ?></td>
                            <td><?= $r['ip_online'] ?></td>
                            <td><?= $r['browser'] ?></td>
                            <td><?= $r['time_online'] ?></td>
                            <td><a href="?action=delete&id_online=<?= $r['id_online'] ?>">حذف</a></td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>
            </div>
        </div><!-- End row -->
    </div><!-- End container -->
</section><!-- End charts -->


<!-- Start footer -->
<footer class="footer">
    <div class="container">

        <div class="footer-links" align="center">
            <ul>
                <li><a href="#" class="active">رئيسية اللوحة</a></li>
                <li><a href="#">الاحصائيات</a></li>
                <li><a href="../../index.php">توجه للموقع</a></li>
            </ul>
        </div><!-- End copy-right -->

    </div><!-- End container -->
</footer><!-- End footer -->
<div class="clearfix"></div>

<script src="../dits/js/jquery-2.1.3.min.js"></script>
<script src="../dits/js/bootstrap.min.js"></script>
<script src="../dits/js/jquery.nicescroll.min.js"></script>
<script src="../dits/js/Chart.min.js"></script>
<script src="../dits/js/custom.js"></script>
<script type="text/javascript">
    Chart.defaults.global.responsive = true;
    Chart.defaults.global.scaleFontFamily = "'JF Flat Regular', 'Sans-Serif', 'tahoma'";
    // line chart data
    var buyerData = {
        labels: ["0", "1", "2", "3", "4", "5"],
        datasets: [
            {
                fillColor: "rgba(89,220,194,0.4)",
                strokeColor: "#1abc9c",
                pointColor: "#1abc9c",
                pointStrokeColor: "#fff",
                data: [65, 59, 80, 81, 56, 55, 40]
            },
            {
                fillColor: "rgba(248,107,79,0.2)",
                strokeColor: "#f86b4f",
                pointColor: "#f86b4f",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(151,187,205,1)",
                data: [28, 48, 40, 19, 86, 27, 90]
            }

        ]
    }

    // get line chart canvas
    var buyers = document.getElementById('buyers').getContext('2d');
    // draw line chart
    new Chart(buyers).Line(buyerData);

    ////////////////////////////////

    Chart.defaults.global.responsive = true;
    Chart.defaults.global.tooltipFontFamily = "'JF Flat Regular', 'Sans-Serif', 'tahoma'";
    // pie chart data
    var pieData = [
        {
            value: 30,
            color: "#eeeeee",
            highlight: "#ddd",
            label: "مساحة فارغة"
        },
        {
            value: 15,
            color: "#47d1b6",
            highlight: "#59dcc2",
            label: "ملفات مؤقتة"
        },
        {
            value: 35,
            color: "#1abc9c",
            highlight: "#2ccaab",
            label: "مساحة مستخدمة"
        }
    ];

    // pie chart options
    var pieOptions = {
        segmentShowStroke: false,
        animateScale: true,
        percentageInnerCutout: 75,
    }
    // get pie chart canvas
    var countries = document.getElementById("countries").getContext("2d");
    // draw pie chart
    new Chart(countries).Doughnut(pieData, pieOptions);

</script>
</body>
</html>