<?php

class Categories_Operations
{
    private $Link;
    private $host = "localhost";
    private $db_user = "root";
    private $db_password = "root";
    private $db_name = "shop1";

    public function __construct()
    {
        $this->Link = mysqli_connect($this->host, $this->db_user, $this->db_password, $this->db_name);
        mysqli_query($this->Link, "set names 'utf8'");
    }

    public function add_categories($name_cat)
    {
        $result = mysqli_prepare($this->Link, "INSERT INTO cat(cat_name) VALUES (?)");
        $result->bind_param("s",$name_cat);
        $result->execute();
    }

    public function get_count_category()
    {

        $sql = "SELECT COUNT(*) from cat";
        $q = mysqli_query($this->Link, $sql);
        $data = mysqli_fetch_row($q);
        echo $data[0];
    }
    public function get_main_category()
    {

        $sql = "SELECT * from cat ";
        $query2 = mysqli_query($this->Link, $sql);
        $data = array();
        while ($row = mysqli_fetch_array($query2)) {
            $data[] = $row;
        }
        return $data;
    }

    public function delete_categories($id_cat)
    {

        $sql = "delete from cat WHERE cat_id='$id_cat'";
        mysqli_query($this->Link, $sql);
    }
    public function edit_categories($id_cat,$name_cat)
    {
        $result = mysqli_prepare($this->Link, "UPDATE cat SET cat_name=? WHERE cat_id=?");
        $result->bind_param("ss",$name_cat,$id_cat);
        $result->execute();
    }

    public function get_id_category($cat_id)
    {
        $sql = "SELECT * from cat WHERE cat_id='$cat_id' ";
        $query2 = mysqli_query($this->Link, $sql);
        $data = array();
        while ($row = mysqli_fetch_array($query2)) {
            $data[] = $row;
        }
        return $data;
    }
}