<?php

class user_Operations
{
    private $Link;
    private $host = "localhost";
    private $db_user = "root";
    private $db_password = "root";
    private $db_name = "shop1";

    public function __construct()
    {
        $this->Link = mysqli_connect($this->host, $this->db_user, $this->db_password, $this->db_name);
        mysqli_query($this->Link, "set names 'utf8'");
    }

    public function login($username,$password)
    {
        $sql="select * from accounts WHERE username='$username' AND password='$password'";
        $query=mysqli_query($this->Link,$sql);
        if(mysqli_num_rows($query)==0)
        {
            return null;
        }
        else
        {
            $row=mysqli_fetch_array($query);
            return $row;
        }
    }
    public function sign_up($username,$email,$password)
    {
        $hash=hash('sha256',$password);
        $string=md5(uniqid(rand(),true));
        $salt=substr($string,0,3);
        $hash=hash('sha256',$salt.$hash);
        $sql="insert into accounts(username,password,email,salt)VALUE (?,?,?,?)";
        $result= mysqli_prepare($this->Link,$sql);
        $result->bind_param("ssss",$username,$hash,$email,$salt);
        $result->execute();
    }

    public function get_accounts()
    {
        $sql = "SELECT * from accounts";
        $query_cart = mysqli_query($this->Link, $sql);
        $data_cart = array();
        while ($row_cart = mysqli_fetch_array($query_cart)) {
            $data_cart[] = $row_cart;
        }
        return $data_cart;
    }

    public function delete_accounts($account_id)
    {
        $sql = "delete from accounts WHERE account_id='$account_id'";
        mysqli_query($this->Link, $sql);
    }


}