<?php
include_once "geoiploc.php";

class admin_page
{
    private $link;
    private $host = "localhost";
    private $user = "root";
    private $pass = "root";
    private $name_db = "shop1";


    public function __construct()
    {
        $this->link = mysqli_connect($this->host, $this->user, $this->pass, $this->name_db);
        mysqli_query($this->link, "set names 'utf8'");
    }

    public function add_ip_online()
    {
        if (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== FALSE)
            $browser = 'Internet explorer';
        elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Trident') !== FALSE) //For Supporting IE 11
            $browser = 'Internet explorer';
        elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Firefox') !== FALSE)
            $browser = 'Mozilla Firefox';
        elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Chrome') !== FALSE)
            $browser = 'Google Chrome';
        elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mini') !== FALSE)
            $browser = "Opera Mini";
        elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Opera') !== FALSE)
            $browser = "Opera";
        elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Safari') !== FALSE)
            $browser = "Safari";
        else
            $browser = 'Something else';

        $ip_online = getenv('REMOTE_ADDR');
        $country=getCountryFromIP($ip_online, " NamE ");
        $time_on = time();
        $sql = "select * from online WHERE ip_online='$ip_online'";
        $result = mysqli_query($this->link, $sql);
        $num_on = mysqli_num_rows($result);
        if ($num_on == 0) {
            $sql2 = "insert into online (ip_online,time_online,browser,Country) VALUE ('$ip_online','$time_on','$browser','$country')";
            mysqli_query($this->link, $sql2);
        } else {
            $sql3 = "update online set time_online='$time_on',browser='$browser' WHERE ip_online='$ip_online'";
            mysqli_query($this->link, $sql3);
        }
    }


    public function get_ip_online()
    {
        $time_on_now = time() - 300;
        $sql = "select * from online WHERE time_online>'$time_on_now'";
        $online_now = mysqli_query($this->link, $sql);
        $row = mysqli_num_rows($online_now);
        echo $row;
    }

    public function get_all_ip_online()
    {

        $sql = "SELECT COUNT(*) from online";
        $q = mysqli_query($this->link, $sql);
        $data = mysqli_fetch_row($q);
        echo $data[0];
    }

    public function get_online()
    {

        $sql = "SELECT * from online";
        $q = mysqli_query($this->link, $sql);
        $data_online = array();
        while ($row_online = mysqli_fetch_array($q)) {
            $data_online[] = $row_online;
        }
        return $data_online;
    }
}

