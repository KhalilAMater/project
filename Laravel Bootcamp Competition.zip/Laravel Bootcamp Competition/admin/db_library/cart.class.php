<?php

class cart_admin
{

    private $Link;
    private $host = "localhost";
    private $db_user = "root";
    private $db_password = "root";
    private $db_name = "shop1";

    public function __construct()
    {
        $this->Link = mysqli_connect($this->host, $this->db_user, $this->db_password, $this->db_name);
        mysqli_query($this->Link, "set names 'utf8'");
    }

    public function get_all_cart()
    {
        $sql = "SELECT * from cart WHERE is_active=0  ORDER BY cart_id DESC";
        $query_cart = mysqli_query($this->Link, $sql);
        $data_cart = array();
        while ($row_cart = mysqli_fetch_array($query_cart)) {
            $data_cart[] = $row_cart;
        }
        return $data_cart;
    }

    public function get_count_cart()
    {
        $sql = "SELECT COUNT(*) from cart";
        $q = mysqli_query($this->Link, $sql);
        $data = mysqli_fetch_row($q);
        echo $data[0];
    }

    public function get_account_cart($account_id)
    {
        $sql = "SELECT username from accounts WHERE account_id='$account_id'";
        $query_cart = mysqli_query($this->Link, $sql);
        $data_cart = array();
        while ($row_cart = mysqli_fetch_array($query_cart)) {
            $data_cart[] = $row_cart;
        }
        return $data_cart;
    }

    public function get_products_cart($p_id)
    {
        $sql = "SELECT * from products WHERE p_id='$p_id'";
        $query_cart = mysqli_query($this->Link, $sql);
        $data_cart = array();
        while ($row_cart = mysqli_fetch_array($query_cart)) {
            $data_cart[] = $row_cart;
        }
        return $data_cart;
    }

    public function delete_cart($id_cart)
    {
        $sql = "delete from cart WHERE cart_id='$id_cart'";
        mysqli_query($this->Link, $sql);
    }

    public function get_count_cart_un_active()
    {

        $sql = "select COUNT(*) from cart WHERE is_active=1";
        $q = mysqli_query($this->Link, $sql);
        $data = mysqli_fetch_row($q);
        echo $data[0];
    }

    public function get_all_cart_un_active()
    {
        $sql = "SELECT * from cart  WHERE is_active=1";
        $query_cart = mysqli_query($this->Link, $sql);
        $data_cart = array();
        while ($row_cart = mysqli_fetch_array($query_cart)) {
            $data_cart[] = $row_cart;
        }
        return $data_cart;
    }

    public function edit_cart_is_active($cart_id)
    {
        $result = mysqli_prepare($this->Link, "UPDATE cart SET is_active=0 WHERE cart_id=?");
        $result->bind_param("s",$cart_id);
        $result->execute();
    }

    public function get_cat_cart($p_id)
    {
        $sql = "SELECT * from cat WHERE cat_id='$p_id'";
        $query_cart = mysqli_query($this->Link, $sql);
        $data_cart = array();
        while ($row_cart = mysqli_fetch_array($query_cart)) {
            $data_cart[] = $row_cart;
        }
        return $data_cart;
    }

}