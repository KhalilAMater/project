<?php
session_start();
include_once "db_user/user.class.php";
$user_obj=new user_Operations();
if(isset($_POST['b1']))
{
    $data=$user_obj->login($_POST['form-username'],$_POST['form-password']);
    if($data!=null)
    {
        $_SESSION['form-username']=$data['username'];
        header("Location:home.php");
    }
    else
    {
        echo "login field";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <!-- Mobile viewport optimized -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="dist/css/bootstrap-rtl.min.css" rel="stylesheet">
    <link href="dist/css/font-awesome.min.css" rel="stylesheet">
    <link href="dist/css/admin-style.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-sm-6 col-sm-offset-3 form-box">
            <div class="form-top">
                <div class="form-top-left">
                    <h3>تسجيل الدخول إلى موقعنا</h3>
                    <p>ادخل اسم المستخدم و كلمة المرور لتسجيل الدخول :</p>
                </div>
                <div class="form-top-right">
                    <i class="fa fa-key"></i>
                </div>
            </div>
            <div class="form-bottom">
                <form role="form" action="" method="post" class="login-form">
                    <div class="form-group">
                        <label class="sr-only" for="form-username">اسم المستخدم</label>
                        <input type="text" name="form-username" placeholder="اسم المستخدم" class="form-username form-control" id="form-username">
                    </div>
                    <div class="form-group">
                        <label class="sr-only" for="form-password">كلمة المرور</label>
                        <input type="password" name="form-password" placeholder="كلمة المرور" class="form-password form-control" id="form-password">
                    </div>
                    <button type="submit" name="b1" class="btn btn-primary">تسجيل دخول</button>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-1.11.3.js"></script>

<script src="dist/js/bootstrap.min.js"></script>
</body>
</html>