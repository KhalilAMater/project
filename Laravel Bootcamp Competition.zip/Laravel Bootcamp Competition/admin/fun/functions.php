<?php
function dd($v = null)
{
    echo '<pre>';
    var_dump($v);
    echo '</pre>';
    exit;
}