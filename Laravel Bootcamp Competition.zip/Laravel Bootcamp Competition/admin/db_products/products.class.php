<?php


class products_Operations
{
    private $Link;
    private $host = "localhost";
    private $db_user = "root";
    private $db_password = "root";
    private $db_name = "shop1";

    public function __construct()
    {
        $this->Link = mysqli_connect($this->host, $this->db_user, $this->db_password, $this->db_name);
        mysqli_query($this->Link, "set names 'utf8'");
    }

    public function add_products($p_title, $p_price, $p_desc, $p_img, $cat_id)
    {

        $result = mysqli_prepare($this->Link, "INSERT INTO products(p_title,p_price,p_desc,p_img,cat_id) VALUES (?,?,?,?,?)");
        $result->bind_param("sssss",$p_title,$p_price,$p_desc,$p_img,$cat_id);
        $result->execute();
    }

    public function get_main_category()
    {
        $sql = "SELECT * from cat ";
        $query2 = mysqli_query($this->Link, $sql);
        $data = array();
        while ($row = mysqli_fetch_array($query2)) {
            $data[] = $row;
        }
        return $data;
    }

    public function get_count_products()
    {

        $sql = "SELECT COUNT(*) from products";
        $q = mysqli_query($this->Link, $sql);
        $data = mysqli_fetch_row($q);
        echo $data[0];

    }

    public function get_main_products()
    {

        $sql = "SELECT * from products ";
        $query2 = mysqli_query($this->Link, $sql);
        $data = array();
        while ($row = mysqli_fetch_array($query2)) {
            $data[] = $row;
        }
        return $data;
    }

    public function delete_products($id_p)
    {

        $sql = "delete from products WHERE p_id='$id_p'";
        mysqli_query($this->Link, $sql);
    }
    public function edit_products($p_title, $p_price, $p_desc, $p_img, $cat_id,$p_id)
    {
        $result = mysqli_prepare($this->Link, "UPDATE products SET p_title=?,p_price=?,p_desc=?,p_img=?,cat_id=? WHERE p_id= ?");
        $result->bind_param("ssssss",$p_title,$p_price,$p_desc,$p_img,$cat_id,$p_id);
        $result->execute();
    }




    public function get_id_products($p_id)
    {

        $sql = "SELECT * from products WHERE p_id='$p_id'";
        $query2 = mysqli_query($this->Link, $sql);
        $data = array();
        while ($row = mysqli_fetch_array($query2)) {
            $data[] = $row;
        }
        return $data;
    }

    public function get_id_category($cat_id)
    {
        $sql = "SELECT cat_name from cat WHERE cat_id='$cat_id' ";
        $query2 = mysqli_query($this->Link, $sql);
        $data = array();
        while ($row = mysqli_fetch_array($query2)) {
            $data[] = $row;
        }
        return $data;
    }


}