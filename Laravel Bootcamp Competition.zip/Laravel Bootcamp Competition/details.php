<?php
session_start();
include_once("db_library/accounts.class.php");
include_once "db_library/home_class.php";
$min_obj = new home_page();
$main_obj = new accounts();
?>
<!DOCTYPE html>
<html>
<head>
    <!-- Website Title & Description for Search Engine purposes -->
    <title></title>
    <meta name="description"
          content="Learn how to code your first responsive website with the new Twitter Bootstrap 3.">

    <meta charset="UTF-8">
    <!-- Mobile viewport optimized -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <link href="dist/css/font-awesome.min.css" rel="stylesheet">


    <!-- Bootstrap core CSS -->
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="dist/css/bootstrap-rtl.min.css" rel="stylesheet">
    <link href="dist/css/sweetalert.css" rel="stylesheet">

    <!-- Include Modernizr in the head, before any other Javascript -->
    <script src="includes/js/modernizr-2.6.2.min.js"></script>

    <![endif]-->

    <!-- Custom CSS -->
    <link rel="stylesheet" href="includes/css/styles.css">


</head>
<body>

<div class="container-fluid">

    <!-- header -->
    <div class="row">

        <div class="col-sm-2 logo">موقع متجر أون لاين</div>
        <div class="col-sm-3 search">

            <span class="glyphicon glyphicon-search"></span>
            <input type="text" name="" id="" placeholder="ابحث داخل متجر أون لاين"/>

        </div>

        <div class="col-sm-4 auth-area">

            <div>
                <?php
                if (isset($_SESSION['id']) == 0) {
                    echo ' <a href="signin.php">تسجيل الدخول</a>
                |
                               <a href="signup.php">مستخدم جديد</a>';
                } else {
                    echo $_SESSION['name'];
                    echo ' <a href="index.php" class="out">تسجيل الخروج</a>';
                }
                ?>
            </div>

        </div>

        <div class="col-sm-3 call">

            <div>

                <span class="glyphicon glyphicon-alert"></span>
                لاتتردد في الاتصال بنا على +972597063252

            </div>

        </div>

    </div>
    <!-- menu -->
    <div class="row menu">

        <div class="col-sm-8">
            <div class="main-menu">
                <a href="index.php" style="margin-left: 20px;">الرئيسية</a>
                <?php
                $cat_data = $min_obj->get_main_category();
                foreach ($cat_data as $ycat_data) { ?>
                    <a href="category.php?category_id=<?=$ycat_data['cat_id']?>" style="margin-left: 20px;"><?= $ycat_data["cat_name"] ?></a>
                <?php } ?>

            </div>
        </div>
        <div class="col-sm-2 Sales">

            <a href="">SALES</a>
            <span class="glyphicon glyphicon-fire"></span>
        </div>
        <div class="col-sm-2 card">
            <span class="glyphicon glyphicon-shopping-cart"></span>
            <a href="showCart.php">سلة المشتريات
                (
                <span class="total"><?php if (isset($_SESSION['cart']) == null) {
                        echo "0";
                    } else {
                        echo count($_SESSION['cart']);
                    }

                    ?></span>
                )
            </a>
        </div>
    </div>
    <!-- menu -->
    <!-- contents -->
    <div class="row">

        <div class="col-sm-9">


            <div class="white-box"
                 style="margin-top: 10px; visibility: visible; animation-name: fadeInDown;">

                <div class="row" style="padding-top:10px; padding-right:10px;">
                    <div class="col-sm-6" style="color:#178FAF; font-size:13px;">
                        <span class="glyphicon glyphicon-align-justify"></span>
                        تفصيل المنتج
                    </div>
                    <div class="col-sm-6" style="color:#178FAF; font-size:13px; text-align:left; ">
                        <div style="padding-left:10px;">
                            <span class="glyphicon glyphicon-eye-open" style="font-size:14px; "></span> (300)
                            <span class="glyphicon glyphicon-thumbs-up" style="font-size:14px;"></span> (200)
                        </div>

                    </div>
                </div>
                <?php
                if (isset($_GET['product_id'])) {
                    $product_id = $_GET['product_id'];
                    $ma = $min_obj->get_all_products($product_id);
                    foreach ($ma as $s) {
                        ?>
                        <div class="row" style="padding:10px;">
                            <div class="col-sm-6">
                                <div>
                                    <img
                                        src="products_img/<?= $s['p_img'] ?>" align="right" class="img-thumbnail zoom"
                                        style="margin-right:10px;" border="0">
                                </div>
                                <div style="height:10px; clear:both"></div>
                            </div>
                            <div class="col-sm-6">

                                <span>العنوان : <?= $s['p_title'] ?></span>
                                <br>
                                <div style="margin-top:10px;"></div>
                                <span>السعر :<?= $s['p_price'] ?>₪</span>
                                <div style="margin-top:10px;"></div>
                                <span><p>الوصف : <?= $s['p_desc'] ?></p></span>

                                <div style="margin-top:10px; margin-bottom:10px;">
                                    <input type="hidden" name="" id="" value="<?= $s['p_id'] ?>"
                                           class="current-id"/>
                                    <a href="#" class="btn btn-success add-cart" style="font-size:12px;">
                                        <span class="glyphicon glyphicon-check"></span>
                                        اطلبه الان
                                    </a>
                                    <span class="current_loader" style="display:none;"><img src="images/ajax-loader.gif"
                                                                                            width="20"
                                                                                            height="20"/></span>
                                </div>

                               <span style="color:#817e7e;">
                              <span class="glyphicon glyphicon-eye-open" style="font-size:14px; color:#817e7e"></span> (300)
                              <span class="glyphicon glyphicon-thumbs-up" style="font-size:14px; color:#817e7e"></span> (200)
                            </span>
                                <div style="clear:both; height:10px;"></div>
                            </div>
                        </div>

                    <?php }
                }
                ?>

            </div>
        </div>
        <div class="col-sm-3">

            <div class="white-box">
                <div class="row" style="padding-top:10px; padding-right:10px;">
                    <div class="col-sm-6" style="color:#F3C634; font-size:13px;">
                        <span class="glyphicon glyphicon-align-justify"></span>
                        الأكثر طلبا
                    </div>
                    <div class="col-sm-6" style="color:#F3C634; font-size:13px; text-align:left; ">
                        <div style="padding-left:10px;">
                            <span class="glyphicon glyphicon-eye-open" style="font-size:14px; "></span> (300)
                            <span class="glyphicon glyphicon-thumbs-up" style="font-size:14px;"></span> (200)
                        </div>

                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box" style="border:none;">
                            <?php
                            $cat_data = $min_obj->get_main_cart();

                            foreach ($cat_data as $ycat_data) { ?>

                                <?php
                                $products_data = $min_obj->get_cart_products($ycat_data['products_id']);
                                foreach ($products_data as $s) {
                                    ?>
                                    <div class="products_box">
                                        <div><img src="products_img/<?= $s['p_img'] ?>" class="img-thumbnail"></div>
                                        <div><?= $s['p_title'] ?></div>
                                        <div><?= $s['p_price'] ?></div>
                                        <div>
                                            <input type="hidden" name="" id="" value="<?= $s['p_id'] ?>"
                                                   class="current-id"/>
                                            <input type="button" name="" id="" value="اطلب الان"
                                                   class="btn btn-danger add-cart"/>
                                        <span class="current_loader" style="display:none;">
                                        <img src="images/ajax-loader.gif" width="20" height="20"/>
                                        </span>
                                        </div>
                                        <div><i class="fa fa-eye"></i>300 <i class="fa fa-thumbs-up"></i>200</div>
                                    </div>
                                    <?php
                                }
                                ?>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
            <div style="border-color:#B7B1B1; border-style:dashed; border-width:1px;margin-top:10px; text-align:center; padding:20px; font-size:20px;" class="rounded-corner">
                <div>
                    مساحة اعلانية .... اتصل الان واحجز اعلانك
                </div>
                <div style=" padding-left:10px;" align="left">
                    <a href="" class="btn btn-info">احجزه الان</a>
                </div>
            </div>

            <div class="white-box">
                <div class="row" style="padding-top:10px; padding-right:10px;">
                    <div class="col-sm-6" style="color:#F3C634; font-size:13px;">
                        <span class="glyphicon glyphicon-align-justify"></span>
                        الأكثر مشاهدة
                    </div>
                    <div class="col-sm-6" style="color:#F3C634; font-size:13px; text-align:left; ">
                        <div style="padding-left:10px;">
                            <span class="glyphicon glyphicon-eye-open" style="font-size:14px; "></span> (300)
                            <span class="glyphicon glyphicon-thumbs-up" style="font-size:14px;"></span> (200)
                        </div>

                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box" style="border:none;">
                            <?php
                            $cat_data = $min_obj->get_main_cart();

                            foreach ($cat_data as $ycat_data) { ?>

                                <?php
                                $products_data = $min_obj->get_cart_products($ycat_data['products_id']);
                                foreach ($products_data as $s) {
                                    ?>
                                    <div class="products_box">
                                        <div><img src="products_img/<?= $s['p_img'] ?>" class="img-thumbnail"></div>
                                        <div><?= $s['p_title'] ?></div>
                                        <div><?= $s['p_price'] ?></div>
                                        <div>
                                            <input type="hidden" name="" id="" value="<?= $s['p_id'] ?>"
                                                   class="current-id"/>
                                            <input type="button" name="" id="" value="اطلب الان"
                                                   class="btn btn-danger add-cart"/>
                                        <span class="current_loader" style="display:none;">
                                        <img src="images/ajax-loader.gif" width="20" height="20"/>
                                        </span>
                                        </div>
                                        <div><i class="fa fa-eye"></i>300 <i class="fa fa-thumbs-up"></i>200</div>
                                    </div>
                                    <?php
                                }
                                ?>
                            <?php } ?>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-12">
                        <div style="padding-left:10px; padding-bottom:20px; padding-top:10px;" align="left">

                            <a href="">
                                <span class="glyphicon glyphicon-th"></span>
                                أرشيف الاكثر مشاهدة
                            </a>
                        </div>
                    </div>
                </div>

            </div>


        </div>

    </div>
    <!--Left contents -->
    <!-- contents -->
    <!-- about -->
    <div class="row about">
        <div class="col-sm-8">
            <h6> متجر أون لاين </h6>
            <p>
                موقع فلسطيني يقدم خدماته لأهالينا في قطاع غزة , الموقع مخصص لبيع الادوات الالكترونية مع العلم أن خدمة التوصيل مجانية
                . كل ما عليك هو الشراء والدفع عند معاينة واستلام بضاعتك موقع فلسطيني يقدم خدماته لأهالينا في قطاع غزة ,
                الموقع مخصص لبيع الادوات الالكترونية مع العلم أن خدمة التوصيل مجانية . كل ما عليك هو الشراء والدفع عند معاينة
                واستلام بضاعتك
            </p>
        </div>

        <div class="col-sm-4">
            <h6> عن الشركة </h6>
            <ul>
                <li><a href="">من نحن</a></li>
                <li><a href=""> اتصل بنا</a></li>
                <li><a href=""> الموزعون</a></li>
                <li><a href=""> سياسة العمل</a></li>
            </ul>
        </div>
    </div>
    <!-- about -->

    <!-- footer -->
    <div class="row footer">
        <div class="col-sm-8">
            <p>جميع الحقوق محفوظة لمتجر أون لاين 2016</p>
        </div>
        <div class="col-sm-4">
            <i class="fa fa-facebook-square"></i>
            <i class="fa fa-twitter-square fa-lg"></i>
            <i class="fa fa-pinterest-square"></i>

        </div>
    </div>
    <!-- footer -->

</div>


<!-- All Javascript at the bottom of the page for faster page loading -->

<script src="js/jquery-1.11.3.js"></script>

<script src="dist/js/bootstrap.min.js"></script>
<script src="dist/js/sweetalert.min.js"></script>
<script src="dist/js/sweetalert-dev.js"></script>
<script src="js/jquery.playSound.js"></script>
<script src='dist/js/jquery-1.8.3.min.js'></script>
<script src='dist/js/jquery.elevatezoom.js'></script>

<script>
    $('#zoom_01').elevateZoom({
        zoomType: "inner",
        cursor: "crosshair",
        zoomWindowFadeIn: 500,
        zoomWindowFadeOut: 750
    });
</script>

<script type="text/javascript">
    $(document).ready(function () {

        $('.add-cart').on("click", function (e) {
            e.preventDefault();
            var selectedid = $(this).parent().find('.current-id').val();
            var a = $(this);
            $(this).parent().find('.current_loader').show();
            //alert(selectedid);
            $.ajax({
                type: "POST",
                url: "services/add_cart.php",
                data: {"p_id": selectedid},
                dataType: "json",
                cache: "false",
                success: function (data) {
                    $('.total').text(data).fadeOut('slow').fadeIn('slow').css("font-size", "18px");
                    $.playSound('add');
                    a.parent().find('.current_loader').hide();
                }
            });

        })


        $(window).scroll(function () {
            if ($(window).scrollTop() > 10) {
                $('.move-menu').removeClass("sta");
                $('.move-menu').addClass("move");
                $('.move-menu').addClass("alpha60");
            } else {
                $('.move-menu').addClass("sta");
                $('.move-menu').removeClass("move");
                $('.move-menu').removeClass("alpha60");
            }
        });

        $('.out').on("click", function () {
            $.ajax({
                type: "POST",
                url: "services/signout.php",
                data: {},
                cache: "false",
                success: function (data) {
                    swal({
                        title: "تم تسجيل الخروج",
                        text: "سيتم توجيهك للصفحة الرئيسية خلال 2 ثانية",
                        timer: 2000,
                        showConfirmButton: false
                    });
                }
            });
        })

        $('.sign-in-btn').on("click", function () {
            $.ajax({
                type: "POST",
                url: "services/signin.php",
                data: $('.sign-in').serialize(),
                cache: "false",
                success: function (e1) {
                    var my_data = JSON.parse(e1);
                    if (my_data.result == 'success') {
                        swal({
                            title: "نجاح عملية تسجيل الدخول",
                            text: "نتمنى لك قضاء وقت ممتع",
                            type: "success",
                            showCancelButton: false,
                            confirmButtonColor: "#DD6B55",
                            confirmButtonText: "تابع التسوق .. شكرا لك",
                            cancelButtonText: "No, cancel plx!",
                            closeOnConfirm: false,
                            closeOnCancel: false
                        }, function (isConfirm) {
                            if (isConfirm) {
                                window.location = "index.php";
                            }
                        });
                    }
                    else if (my_data.result == 'fail') {
                        sweetAlert("فشل تسجيل الدخول", "البريد الالكتروني أو كلمة المرور خطأ", "error");
                    }

                }
            });
        })

    });
</script>
</body>
</html>

