<?php
session_start();
include_once "db_library/home_class.php";
$min_obj = new home_page();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <!-- Mobile viewport optimized -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <!-- Website Title & Description for Search Engine purposes -->
    <title></title>
    <meta name="description"
          content="Learn how to code your first responsive website with the new Twitter Bootstrap 3.">
    <!-- Bootstrap core CSS -->
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="dist/css/bootstrap-rtl.min.css" rel="stylesheet">
    <link href="dist/css/font-awesome.min.css" rel="stylesheet">
    <link href="dist/css/sweetalert.css" rel="stylesheet">
    <link rel="stylesheet" href="dist/css/animate.css">
    <!-- Custom CSS -->

    <link rel="stylesheet" href="includes/css/styles.css">
    <style>.alert {
            display: none;
        }</style>

</head>
<body>

<div class="container-fluid move-menu sta"
     style="background-color: #FFFFFF;top: 0; left: 0;width: 100%;z-index: 10023;">

    <!--Start header -->
    <div class="row">

        <div class="col-sm-2 logo">موقع متجر أون لاين</div>
        <div class="col-sm-3">
            <div class="search">
                <form>
                    <span class="glyphicon glyphicon-search"></span>
                    <input type="text" name="" id="" placeholder="ابحث داخل متجر أون لاين"/>
                </form>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="auth-area">
                <?php
                if (isset($_SESSION['id']) == 0) {
                    echo ' <a href="signin.php">تسجيل الدخول</a>
                |
                               <a href="signup.php">مستخدم جديد</a>';
                } else {
                    echo $_SESSION['name'];
                    echo ' <a href="index.php" class="out">تسجيل الخروج</a>';
                }
                ?>
            </div>
        </div>
        <div class="col-sm-3 call">
            <div>
                <span class="glyphicon glyphicon-bell"></span>
                لاتتردد في الاتصال بنا على +972599698234
            </div>
        </div>
    </div>
    <!--End header -->

    <!--Start menu -->
    <div class="row menu">
        <div class="col-sm-8">
            <div class="main-menu">
                <a href="index.php" style="margin-left: 20px;">الرئيسية</a>
                <?php
                $cat_data = $min_obj->get_main_category();
                foreach ($cat_data as $ycat_data) { ?>
                    <a href="category.php?category_id=<?= $ycat_data['cat_id'] ?>"
                       style="margin-left: 20px;"><?= $ycat_data["cat_name"] ?></a>
                <?php } ?>
            </div>
        </div>
        <div class="col-sm-2">
            <a href="#">SALES</a>
            <span class="glyphicon glyphicon-fire"></span>
        </div>
        <div class="col-sm-2">
            <span class="glyphicon glyphicon-shopping-cart"></span>
            <a href="showCart.php" class="white-link">
                سلة المشتريات
                (
                <span class="total"><?php if (isset($_SESSION['cart']) == null) {
                        echo "0";
                    } else {
                        echo count($_SESSION['cart']);
                    }

                    ?></span>
                )
            </a>
        </div>
    </div>
    <!--End menu -->
</div>
<div class="container-fluid">
    <!--Start contents -->
    <div class="row">
        <div class="col-sm-9">
            <div class="white-box wow fadeInDown" style="margin-top: 10px; visibility: visible;">
                <div class="row" style="padding-top:10px; padding-right:10px;">
                    <div class="col-sm-12" style="color:#F3C634; font-size:13px;">
                        <i class="fa fa-cart-plus"></i>
                        سلة المشتريات
                    </div>
                </div>
                <div class="row" style="padding-top:10px; padding-right:10px; padding-left:10px;">
                    <div class="col-sm-12" style="font-size:13px;">
                        <div align="center"></div>
                        <div class="alert alert-success success" role="alert">تمت عملية الحذف بنجاح.</div>
                        <div class="alert alert-danger danger" role="alert">فشلت العملية.</div>
                        <?php
                        if (isset($_SESSION['cart']) == null && empty($_SESSION['cart'])) {
                            echo 'لايوجد منتجات';
                        } else {
                            ?>
                            <table class="table table-bordered table-responsive table-striped table-sale"
                                   style="font-size: 12px;">
                                <tbody>
                                <tr style="font-weight:bold">
                                    <td>المنتج</td>
                                    <td>الكمية</td>
                                    <td>السعر</td>
                                    <td>المجموع</td>
                                    <td align="center">العمليات</td>
                                </tr>
                                <?php
                                foreach ($_SESSION['cart'] as $id => $x) {
                                    $products_details = $min_obj->get_specific_products($id); ?>
                                    <tr style="font-weight:bold">
                                        <td><?= $products_details['p_title']; ?></td>
                                        <td>
                                            <span class="que"><?= $x; ?></span>
                                            <a href="#"><i class="fa fa-arrow-up up"></i></a>
                                            <a href="#"><i class="fa fa-arrow-down down"></i></a>
                                        </td>
                                        <td>
                                            <span class="price"><?= $products_details['p_price']; ?></span>
                                        </td>
                                        <td>
                                            <span class="totals"><?= $products_details['p_price'] * $x; ?></span>
                                            ₪
                                        </td>
                                        <td align="center">
                                    <span class="current_id"
                                          style="display: none;"><?= $products_details['p_id']; ?></span>
                                            <a href="#" class="delete_id"><i class="fa fa-recycle"></i></a>
                                    <span class="alert current_loader">
                                        <img src="images/ajax-loader.gif" width="20" height="20"/>
                                    </span>
                                        </td>

                                    </tr>
                                <?php } ?>
                                <tr style="font-weight:bold;">
                                    <td colspan="3" align="center">
                                        الاجمالي ( ₪ )
                                    </td>
                                    <td style="color: #5cb85c;">
                                        <span class="total-sum"></span>
                                        ₪
                                    </td>
                                    <td></td>
                                </tr>
                                </tbody>
                            </table>
                            <div align="center" style="padding:10px;">
                                <button class="btn btn-danger empty-sale form-control">افراغ سلة المشتريات</button>
                            </div>

                            <div align="center" style="padding:10px;">
                                <button class="btn btn-success complete form-control">اتمام عملية الشراء</button>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="white-box">
                <div class="row" style="padding-top:10px; padding-right:10px;">
                    <div class="col-sm-6" style="color:#F3C634; font-size:13px;">
                        <span class="glyphicon glyphicon-align-justify"></span>
                        الأكثر طلبا
                    </div>
                    <div class="col-sm-6" style="color:#F3C634; font-size:13px; text-align:left; ">
                        <div style="padding-left:10px;">
                            <span class="glyphicon glyphicon-eye-open" style="font-size:14px; "></span> (300)
                            <span class="glyphicon glyphicon-thumbs-up" style="font-size:14px;"></span> (200)
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box" style="border:none;">
                            <?php
                            $cat_data = $min_obj->get_main_cart();

                            foreach ($cat_data as $ycat_data) { ?>

                                <?php
                                $products_data = $min_obj->get_cart_products($ycat_data['products_id']);
                                foreach ($products_data as $s) {
                                    ?>
                                    <div class="products_box">
                                        <div><img src="products_img/<?= $s['p_img'] ?>" class="img-thumbnail"></div>
                                        <div><?= $s['p_title'] ?></div>
                                        <div><?= $s['p_price'] ?></div>
                                        <div>
                                            <input type="hidden" name="" id="" value="<?= $s['p_id'] ?>"
                                                   class="current-id"/>
                                            <input type="button" name="" id="" value="اطلب الان"
                                                   class="btn btn-danger add-cart"/>
                                        <span class="current_loader" style="display:none;">
                                        <img src="images/ajax-loader.gif" width="20" height="20"/>
                                        </span>
                                        </div>
                                        <div><i class="fa fa-eye"></i>300 <i class="fa fa-thumbs-up"></i>200</div>
                                    </div>
                                    <?php
                                    }
                                ?>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>

            <div
                style="border-color:#B7B1B1; border-style:dashed; border-width:1px;margin-top:10px; text-align:center; padding:20px; font-size:20px;"
                class="rounded-corner">
                <div>
                    مساحة اعلانية .... اتصل الان واحجز اعلانك
                </div>
                <div style=" padding-left:10px;" align="left">
                    <a href="" class="btn btn-info">احجزه الان</a>
                </div>
            </div>

            <div class="white-box">
                <div class="row" style="padding-top:10px; padding-right:10px;">
                    <div class="col-sm-6" style="color:#F3C634; font-size:13px;">
                        <span class="glyphicon glyphicon-align-justify"></span>
                        الأكثر مشاهدة
                    </div>
                    <div class="col-sm-6" style="color:#F3C634; font-size:13px; text-align:left; ">
                        <div style="padding-left:10px;">
                            <span class="glyphicon glyphicon-eye-open" style="font-size:14px; "></span> (300)
                            <span class="glyphicon glyphicon-thumbs-up" style="font-size:14px;"></span> (200)
                        </div>

                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box" style="border:none;">
                            <?php
                            $cat_data = $min_obj->get_main_cart();

                            foreach ($cat_data as $ycat_data) { ?>
                                <?php
                                $products_data = $min_obj->get_cart_products($ycat_data['products_id']);
                                foreach ($products_data as $s) {
                                    ?>
                                    <div class="products_box">
                                        <div><img src="products_img/<?= $s['p_img'] ?>" class="img-thumbnail"></div>
                                        <div><?= $s['p_title'] ?></div>
                                        <div><?= $s['p_price'] ?></div>
                                        <div>
                                            <input type="hidden" name="" id="" value="<?= $s['p_id'] ?>"
                                                   class="current-id"/>
                                            <input type="button" name="" id="" value="اطلب الان"
                                                   class="btn btn-danger add-cart"/>
                                        <span class="current_loader" style="display:none;">
                                        <img src="images/ajax-loader.gif" width="20" height="20"/>
                                        </span>
                                        </div>
                                        <div><i class="fa fa-eye"></i>300 <i class="fa fa-thumbs-up"></i>200</div>
                                    </div>
                                    <?php
                                }
                                ?>
                            <?php } ?>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-12">
                        <div style="padding-left:10px; padding-bottom:20px; padding-top:10px;" align="left">

                            <a href="">
                                <span class="glyphicon glyphicon-th"></span>
                                أرشيف الاكثر مشاهدة
                            </a>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
    <!--End contents -->
    <!--Start about -->
    <div class="row about">
        <div class="col-sm-8">
            <p class="title">متجر أون لاين</p>
            <p class="details">موقع فلسطيني يقدم خدماته لأهالينا في قطاع غزة , الموقع مخصص لبيع الادوات الالكترونية مع العلم أن خدمة
                التوصيل مجانية . كل ما عليك هو الشراء والدفع عند معاينة واستلام بضاعتك موقع فلسطيني يقدم خدماته لأهالينا
                في قطاع غزة , الموقع مخصص لبيع الادوات الالكترونية مع العلم أن خدمة التوصيل مجانية . كل ما عليك هو الشراء والدفع عند
                معاينة واستلام بضاعتك</p>
        </div>
        <div class="col-sm-4">
            <p class="title1">عن الشركة</p>
            <ul>
                <li><a href="#">من نحن</a></li>
                <li><a href="#">اتصل بنا</a></li>
                <li><a href="#">الموزعون</a></li>
                <li><a href="#">سياسة العمل</a></li>
            </ul>
        </div>
    </div>
    <!--End about -->

    <!--Start footer -->
    <div class="row footer">
        <div class="col-sm-8"> جميع الحقوق محفوظة لمتجر أون لاين 2016</div>
        <div class="col-sm-4">
            <div class="footer-icon">
                <a href="#"><i class="fa fa-facebook-square fa-2x"></i></a>
                <a href="#"><i class="fa fa-twitter-square fa-2x"></i></a>
                <a href="#"> <i class="fa fa-pinterest-square fa-2x"></i></a>


            </div>
        </div>
    </div>
    <!--End footer -->

</div>


<!-- All Javascript at the bottom of the page for faster page loading -->

<script src="js/jquery-1.11.3.js"></script>

<script src="dist/js/bootstrap.min.js"></script>
<script src="dist/js/sweetalert.min.js"></script>
<script src="dist/js/sweetalert-dev.js"></script>

<script type="text/javascript">
    $(document).ready(function () {


        $(window).scroll(function () {
            if ($(window).scrollTop() > 10) {
                $('.move-menu').removeClass("sta");
                $('.move-menu').addClass("move");
                $('.move-menu').addClass("alpha60");
            } else {
                $('.move-menu').addClass("sta");
                $('.move-menu').removeClass("move");
                $('.move-menu').removeClass("alpha60");
            }
        });

        $('.out').on("click", function () {
            $.ajax({
                type: "POST",
                url: "services/signout.php",
                data: {},
                cache: "false",
                success: function (data) {
                    alert(data);
                }
            });
        })
        $('.complete').on("click", function () {
            $.ajax({
                type: "POST",
                url: "services/complete.php",
                data: {},
                cache: "false",
                success: function (data) {
                    if (data == 'false') {
                        swal({
                            title: "الرجاء تسجيل الدخول ... لتتمكن من اتمام عملية الشراء",
                            text: "هل ترغب بالذهاب الي شاشة تسجيل الدخول ؟",
                            type: "warning",
                            showCancelButton: true,
                            confirmButtonColor: "#DD6B55",
                            confirmButtonText: "نعم",
                            cancelButtonText: "لا",
                            closeOnConfirm: false,
                            closeOnCancel: true
                        }, function (isConfirm) {
                            if (isConfirm) {
                                window.location = "signin.php";
                            }
                        });
                    }
                    else if (data == 'true') {
                        swal({
                            title: "هل انتا متأكد من عملية الشراء",
                            text: "للتأكيد اضغط علي زر موافق",
                            type: "info",
                            showCancelButton: true,
                            confirmButtonColor: "#DD6B55",
                            confirmButtonText: "نعم",
                            cancelButtonText: "لا",
                            closeOnConfirm: false,
                            showLoaderOnConfirm: true,
                        }, function () {
                            setTimeout(function () {
                                swal({
                                    title: "تمت عملية الشراء بنجاح",
                                    text: "سيقوم فريق التسويق بالتواصل معكم لتسليم الطلبية ... علما بأن الدفع عند الاستلام",
                                    type: "success",
                                    showCancelButton: false,
                                    confirmButtonColor: "#DD6B55",
                                    confirmButtonText: "نعم",
                                    cancelButtonText: "لا",
                                    closeOnConfirm: false,
                                    closeOnCancel: true
                                }, function (isConfirm) {
                                    if (isConfirm) {
                                        window.location = "showCart.php";
                                    }
                                });
                            }, 2000);
                        });

                    }
                }
            });
        })

        $('.empty-sale').on("click", function (e) {
            e.preventDefault();
            var parents = $(this).parents().find('.table-sale');
            var selected_id = parents.find('.table-sale').text();
            parents.find('.current_loader').show();
            $.ajax({
                type: "POST",
                url: "services/delete_all_cart.php",
                data: {"p_id": selected_id},
                dataType: "json",
                cache: "false",
                success: function (data) {
                    $('.total').text(data).fadeOut('slow').fadeIn('slow').css("font-size", "18px");
                    parents.hide("5000");
                    $('.empty-sale').hide();
                    $('.complete').hide();
                    $('.alert.success').show().delay(1000).hide("");
                    parents.find('.current_loader').hide();
                }
            })
        });

        $('.up').on("click", function (e) {
            e.preventDefault();
            $(this).parent().parent().find('.que').text(parseInt($(this).parent().parent().find('.que').text()) + 1);
            $(this).parent().parent().parent().find(".totals").text(Math.round(parseFloat($(this).parent().parent().parent().find(".price").text()) * $(this).parent().parent().find(".que").text() * 100) / 100);
            var sum = 0;
            $('.totals').each(function () {
                sum += parseFloat($(this).text());  //Or this.innerHTML, this.innerText
            });

            $('.total-sum').text(Math.round(sum * 100) / 100);
        })

        $('.down').on("click", function (e) {
            e.preventDefault();
            if ($(this).parent().parent().find('.que').text() == 1) {
                return false;
            }
            $(this).parent().parent().find('.que').text(parseInt($(this).parent().parent().find('.que').text()) - 1);
            $(this).parent().parent().parent().find(".totals").text(Math.round(parseFloat($(this).parent().parent().parent().find(".price").text()) * $(this).parent().parent().find(".que").text() * 100) / 100);
            var sum = 0;
            $('.totals').each(function () {
                sum += parseFloat($(this).text());  //Or this.innerHTML, this.innerText
            });

            $('.total-sum').text(Math.round(sum * 100) / 100);
        })

        var sum = 0;
        $('.totals').each(function () {
            sum += parseFloat($(this).text());  //Or this.innerHTML, this.innerText
        });

        $('.total-sum').text(Math.round(sum * 100) / 100);


        $('.delete_id').on("click", function (e) {
            e.preventDefault();
            var parents = $(this).parents('tr'),
                selected_id = parents.find('.current_id').text();
            parents.find('.current_loader').show();
            $.ajax({
                type: "POST",
                url: "services/delete_cart.php",
                data: {"p_id": selected_id},
                dataType: "json",
                cache: "false",
                success: function (data) {
                    $('.total').text(data).fadeOut('slow').fadeIn('slow').css("font-size", "18px");
                    parents.hide("3000");
                    $('.alert.success').show().delay(1000).hide("");
                    parents.find('.current_loader').hide();
                }
            })
        });

        $('.add-cart').on("click", function () {
            var selectedid = $(this).parent().find('.current-id').val();
            $.ajax({
                type: "POST",
                url: "services/add_cart.php",
                data: {"p_id": selectedid},
                dataType: "json",
                cache: "false",
                success: function (data) {
                    $('.total').text(data);
                }
            });
        })
    });
</script>
<script src="dist/js/wow.min.js"></script>
<script src="dist/js/wow.js"></script>
<script>
    new WOW().init();
</script>
</body>
</html>

